"""
PC Commander - Security & Authorization
طبقات الأمان: User ID + PIN + Session + Rate Limiting
"""
import time
import hashlib
import secrets
import threading
from collections import defaultdict
from src.utils.logger import get_logger

logger = get_logger()

_sessions: dict[int, dict] = {}
_pending_pin: dict[int, dict] = {}
_rate_limits: dict[int, list] = defaultdict(list)
_blocked_users: set[int] = set()
_lock = threading.Lock()

SESSION_TIMEOUT    = 3600
PIN_TIMEOUT        = 120
RATE_LIMIT_WINDOW  = 60
RATE_LIMIT_MAX     = 30
MAX_PIN_ATTEMPTS   = 3


def _hash_pin(pin: str) -> str:
    return hashlib.sha256(pin.encode()).hexdigest()


def is_allowed_user(user_id: int, config: dict) -> bool:
    allowed = config.get("telegram", {}).get("allowed_users", [])
    if not allowed:
        return False
    return str(user_id) in [str(u) for u in allowed]


def is_rate_limited(user_id: int) -> bool:
    with _lock:
        now = time.time()
        events = [t for t in _rate_limits[user_id] if now - t < RATE_LIMIT_WINDOW]
        _rate_limits[user_id] = events
        if len(events) >= RATE_LIMIT_MAX:
            return True
        _rate_limits[user_id].append(now)
        return False


def is_blocked(user_id: int) -> bool:
    return user_id in _blocked_users


def block_user(user_id: int):
    _blocked_users.add(user_id)
    logger.warning(f"🚫 تم حجب المستخدم: {user_id}")


def unblock_user(user_id: int):
    _blocked_users.discard(user_id)
    logger.info(f"✅ تم رفع الحجب عن: {user_id}")


def is_session_valid(user_id: int, config: dict) -> bool:
    security = config.get("security", {})
    pin_required = security.get("require_pin", False)
    if not pin_required:
        return True
    with _lock:
        session = _sessions.get(user_id)
        if not session:
            return False
        if time.time() - session["created_at"] > SESSION_TIMEOUT:
            del _sessions[user_id]
            return False
        return True


def create_session(user_id: int):
    with _lock:
        _sessions[user_id] = {
            "created_at": time.time(),
            "token": secrets.token_hex(16)
        }


def invalidate_session(user_id: int):
    with _lock:
        _sessions.pop(user_id, None)


def request_pin_auth(user_id: int, config: dict) -> str:
    pin = config.get("security", {}).get("session_pin", "")
    if not pin:
        create_session(user_id)
        return "SESSION_CREATED"
    with _lock:
        _pending_pin[user_id] = {
            "expires_at": time.time() + PIN_TIMEOUT,
            "attempts": 0
        }
    return "PIN_REQUIRED"


def verify_pin(user_id: int, entered_pin: str, config: dict) -> str:
    pin_hash = _hash_pin(config.get("security", {}).get("session_pin", ""))
    entered_hash = _hash_pin(entered_pin.strip())

    with _lock:
        pending = _pending_pin.get(user_id)
        if not pending:
            return "NO_PENDING"
        if time.time() > pending["expires_at"]:
            del _pending_pin[user_id]
            return "EXPIRED"
        if entered_hash != pin_hash:
            pending["attempts"] += 1
            if pending["attempts"] >= MAX_PIN_ATTEMPTS:
                del _pending_pin[user_id]
                block_user(user_id)
                logger.warning(f"🚫 حُجب {user_id} بعد {MAX_PIN_ATTEMPTS} محاولات خاطئة")
                return "BLOCKED"
            return f"WRONG:{MAX_PIN_ATTEMPTS - pending['attempts']}"
        del _pending_pin[user_id]

    create_session(user_id)
    logger.info(f"✅ جلسة جديدة للمستخدم {user_id}")
    return "OK"


def is_waiting_pin(user_id: int) -> bool:
    with _lock:
        pending = _pending_pin.get(user_id)
        if not pending:
            return False
        if time.time() > pending["expires_at"]:
            del _pending_pin[user_id]
            return False
        return True


def check_authorization(user_id: int, config: dict) -> tuple[bool, str]:
    """
    يتحقق من صلاحية المستخدم بالترتيب:
    1. هل هو في قائمة allowed_users؟
    2. هل هو محجوب؟
    3. هل تجاوز حد الطلبات؟
    4. هل لديه جلسة نشطة (إذا كان PIN مفعّلاً)؟
    يُرجع: (مسموح: bool, سبب الرفض: str)
    """
    if not is_allowed_user(user_id, config):
        logger.warning(f"⛔ محاولة وصول غير مصرّح به: {user_id}")
        return False, "NOT_ALLOWED"

    if is_blocked(user_id):
        return False, "BLOCKED"

    if is_rate_limited(user_id):
        logger.warning(f"⚠️ تجاوز المستخدم {user_id} حد الطلبات")
        return False, "RATE_LIMITED"

    if not is_session_valid(user_id, config):
        return False, "NO_SESSION"

    return True, "OK"


def get_security_report(config: dict) -> str:
    security = config.get("security", {})
    allowed  = config.get("telegram", {}).get("allowed_users", [])
    pin_on   = security.get("require_pin", False)
    active   = len(_sessions)
    blocked  = len(_blocked_users)

    lines = [
        "🔒 **تقرير الأمان**\n",
        f"👤 المستخدمون المصرّح لهم: {len(allowed)} شخص",
        f"🔑 رمز PIN: {'✅ مفعّل' if pin_on else '❌ غير مفعّل'}",
        f"🟢 الجلسات النشطة: {active}",
        f"🚫 المحجوبون: {blocked}",
        f"⏱ انتهاء الجلسة بعد: {SESSION_TIMEOUT // 60} دقيقة من الخمول",
        f"🛡 حد الطلبات: {RATE_LIMIT_MAX} أمر / دقيقة",
    ]
    if blocked > 0:
        lines.append(f"\nالمحجوبون: {', '.join(str(u) for u in _blocked_users)}")
    return "\n".join(lines)
